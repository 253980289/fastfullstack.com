﻿"use strict";

var SDK_CONFIG = {
  appid: 100023,
  appkey: "qvxeobpvfxdzkjfh",
};

const $ = document.querySelector.bind(document);

function nnlog(s) {
  kfssdk.log_(s);
}

const util = {
  showTip(msg, level = 'info') {
    nnlog(msg);
    $('.msg-info').textContent = (level === 'error' ? '错误：' : '') + msg;
  }
};

function get_cur_channel() {
  return $('.room_name').value;
}

function remote_video(remoteUserId) {
  return $('.remote-video_box' + remoteUserId + ' .remote-video');
}

var webrtc = kfssdk.webrtc;

function switch_fullscreen(node) {
  if ("relative" === node.style.position) {
    node.style.position = "absolute";
    node.style.width = "100vw";
    node.style.height = "100vh";
    node.style.left = 0;
    node.style.top = 0;
    node.style.zIndex = 1;
  }else{
    node.style.position = "relative";
    node.style.width = (2 >= webrtc.get_chat_list_count()) ? "100vw" : "50vw";
    node.style.height = (1 >= webrtc.get_chat_list_count()) ? "100vh" : "50vh";
    delete node.style.left;
    delete node.style.top;
    node.style.zIndex = "auto";
  }
}

function switch_fullscreen_self(node) {
    if ("100vw" === node.style.width) {
        node.style.width = "60px";
        node.style.height = "60px";
        node.style.left = "40vw";
    } else {
        node.style.width = "100vw";
        node.style.height = "100vh";
        node.style.left = 0;
    }
}

function init() {
  nnlog("webrtc.create_channel_for_webrtc [" + get_cur_channel() + "]");
  webrtc.create_channel_for_webrtc({
    _channel: get_cur_channel(),
    _channel_option: {
      //   _password: "demo_im", // 订阅密码
      //   _max_user: 100, // 默认100
      //   _join_notify: true, // 默认true，每个新加入/订阅的用户均会双向通知到所有人及将所有人通知给新人
      //   _leave_notify: true, // 默认true，每个离开/取消订阅的用户均会双向通知到所有人及将所有人通知给新人
    },
  });
}

function capture_display_media(force_start) {
  webrtc.capture_display_media(function(user_media, err) {
    $('.my-video').parentNode.style.display = "";
    if (user_media) {
      $('.my-video').srcObject = user_media;
      $('.my-video-no-video').style.display = 'none';
    }else{
      if (!force_start) {
        $(".start_webrtc").style.display = "";
        return;
      }
    }
    start_webrtc();
  });
}

function start_webrtc(btn) {
  nnlog("webrtc.init");
  if (btn) {
    btn.style.display = 'none';
    capture_display_media(true);
    return;
  }
  $('.wait_other_user').style.display = "";
  webrtc.init({
    appid: SDK_CONFIG.appid,
    appkey: SDK_CONFIG.appkey,
    onready: function() {
      nnlog("onready");
      $(".init_room").style.display = "";

      var room_name = kfssdk.parse_url_("room_name");
      if (room_name) {
        $('.room_name').value = room_name;
        init();
      }
    },

    onuser_info: function(msg_body, err_obj, seq) {
      nnlog("onuser_info:" + JSON.stringify(msg_body));
      var remoteUserId = msg_body._uid;
      if (!kfssdk.is_self(remoteUserId)) {
          var user_info = $('.remote-video_box' + remoteUserId + ' .user_info');
          if (user_info) {
              var user = kfssdk.users[remoteUserId];
              user_info.innerText = user.nickname + "@" + user.last_position;
              $('.remote-video_box' + remoteUserId + ' .head_portrait').src = kfssdk.get_head_portrait(user);
          }
      }
    },
    oncreate_channel: function(msg_body, err_obj, seq) {
      nnlog("oncreate_channel:" + JSON.stringify(msg_body));
      // msg_body: {
      //     _info: {
      //         _channel:CHANNEL_NAME, 
      //         _creator:?, 
      //         _create_time:?, 
      //         _appid:?, 
      //         _master:100003, 
      //         _option:?,
      //         _uid_list:[100003,100013], 
      //         _service_seq:?,
      //         _public_data:[?],
      //         _group:?,
      //         _uid_offline_list:[?],
      //     }
      // }
      if (err_obj) {
        util.showTip("意外错误：" + JSON.stringify(err_obj));
        return;
      }
      var info = msg_body._info;
      if (info._channel !== get_cur_channel()) {
        util.showTip("unknow change:" + info._channel);
        return;
      }
      $(".init_room").style.display = "none";
    },

    onmedia_stream_event: function(remoteUserId, mediaStreamRemote, init, remove) {
      nnlog("onmedia_stream_event:" + $('.video-box').style.display);
      var r_video = remote_video(remoteUserId);
      if (init && !r_video) {
        nnlog("onmedia_stream_event:init");
        let node = $('.remote-video_box').cloneNode(true);
        node.className = 'remote-video_box' + remoteUserId;
        node.style.display = 'inline-block';
        r_video = $('.video-box').appendChild(node);
        switch_fullscreen(r_video);
      }else if (remove && r_video) {
        nnlog("onmedia_stream_event:remove");
        let node = $('.remote-video_box' + remoteUserId);
        node && node.parentNode.removeChild(node);
      }else if (r_video) {
        nnlog("onmedia_stream_event:r_video");
        if ("string" === typeof mediaStreamRemote) {
          r_video.src = null;
          r_video.srcObject = null;
          r_video.src = mediaStreamRemote;
        }else{
          r_video.srcObject = mediaStreamRemote;
        }
        if (mediaStreamRemote) {
          $('.remote-video_box' + remoteUserId + ' .no-video').style.display = 'none';
        }
      }
      window.r_video = r_video;
      $('.wait_other_user').style.display = webrtc.get_chat_list_count() > 0 ? "none" : "";
      $('.video-box').style.display = webrtc.get_chat_list_count() <= 0 ? "none" : "";
    },
  });
}

function main() {
  nnlog("ver:9");
  if (!window.RTCPeerConnection) {
    util.showTip('你的浏览器不支持WebRTC，无法使用');
    return;
  }
  var create_or_join_room = function(argument) {
    var room_name = $('.room_name').value;
    if (!room_name.trim().length) {
      util.showTip("请输入房间名");
      $('.room_name').focus();
      return;
    }
    kfssdk.to_url_(kfssdk.add_or_replace_url_params_("room_name", room_name));
  }
  $(".create_room").onclick = function() {
    create_or_join_room();
  }

  $(".join_room").onclick = function() {
    create_or_join_room();
  }
  $("body").onkeydown = function(event) {
     if (event.keyCode == "13") {
         create_or_join_room();
     }
  };
  if (!kfssdk.parse_url_("room_name")) {
      $(".init_room").style.display = "";
      return;
  }
  capture_display_media();
};

main();