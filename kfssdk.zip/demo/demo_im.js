﻿"use strict";

var $ = $ || function(key) {
    return document.querySelector(key);
}

function nnlog(s) {
  // kfssdk.log_(s);
  $('#log').value += s + "\r\n";
}
// var CHANNEL_NAME = "demo_im";
var channel_msg = {
  system: []
};
channel_msg[CHANNEL_NAME] = [];

function get_cur_channel() {
  return $('#channel').value;
}

function switch_channel() {
  $('#msg_list').value = channel_msg[get_cur_channel()].join("\r\n");
}

function publish() {
  var channel = get_cur_channel();
  var msg = $('#msg');
  nnlog("publish [" + channel + "] " + msg.value);
  kfssdk.publish_channel_msg(channel, "say", {
    data: msg.value
  });
  msg.value = "";
  msg.focus();
}

function init() {
  nnlog("onready");
  nnlog("kfssdk.create_channel [" + CHANNEL_NAME + "]");
  kfssdk.create_channel({
    _channel: CHANNEL_NAME,
    _channel_option: {
      //   _password: "demo_im", // 订阅密码
      //   _max_user: 100, // 默认100
      _max_keep_msg_list_len: 20, // 默认0，处理后立即删除
      //   _max_keep_msg_time: 0, // 默认0，处理后立即删除
      //   _join_notify: true, // 默认true，每个新加入/订阅的用户均会双向通知到所有人及将所有人通知给新人
      //   _leave_notify: true, // 默认true，每个离开/取消订阅的用户均会双向通知到所有人及将所有人通知给新人
      //   _max_offline_wait_time: 0, // 默认0，立即移除该用户
      //   _public: false, // 默认false，仅当前app内可见，作用域为当前app范围；否为为全系统范围
      //   _auto_destroy: true, // 默认true，当频道无人时自动销毁
      //   _allow_publish_users: null, // 默认nil，即允许所有频道范围(app或全局)
    },
    // _begin_service_seq: Number(kfssdk.getItem("demo_im_seq")) || 0, // 如果频道已存在，则接收从这个消息序号开始的所有消息，默认为nil，表示只接收之后的新消息；此条仅_last_msg_len为空时有效
    _last_msg_len: 20, // 如果频道已经存在，则获取最新消息条数，默认为空，按_begin_service_seq计算
  });
}

function start() {
  // window.onload = function() {
  var msg = $('#msg');
  msg.select();
  msg.focus();

  nnlog("kfssdk.init");
  kfssdk.init({
    appid: SDK_CONFIG.appid,
    appkey: SDK_CONFIG.appkey,
    onready: init,

    onuser_info: function(msg_body) {
      nnlog("onuser_info:" + JSON.stringify(msg_body));
    },
    oncreate_channel: function(msg_body) {
      nnlog("oncreate_channel:" + JSON.stringify(msg_body));
      nnlog("kfssdk.publish [" + msg_body._info._channel + "]");
      kfssdk.publish_channel_msg(msg_body._info._channel, "hello", {
        data: ("i'm " + kfssdk.nickname)
      });
    },
    ondestroy_channel: function(msg_body) {
      nnlog("ondestroy_channel:" + JSON.stringify(msg_body));
    },
    onpublish_channel_msg: function(msg_body) {
      var data = JSON.stringify(msg_body);
      nnlog("onpublish_channel_msg:" + data);
      channel_msg[msg_body._channel].push(data);
      if (msg_body._channel === get_cur_channel()) {
        $('#msg_list').value += data + "\r\n";
      }
      // kfssdk.setItem(msg_body._channel + "_seq", msg_body._service_seq);
    },
    onsubscribe_channel: function(msg_body) {
      nnlog("onsubscribe_channel:" + JSON.stringify(msg_body));
    },
    onunsubscribe_channel: function(msg_body) {
      nnlog("onunsubscribe_channel:" + JSON.stringify(msg_body));
    },
    onmodify_channel: function(msg_body) {
      nnlog("onchannel_change_channel:" + JSON.stringify(msg_body));
      if (msg_body._user_join) {
          if (msg_body._channel === get_cur_channel()) {
            $('#msg_list').value += "用户【" + msg_body._user_join + "】加入\r\n";
          }
      }
      if (msg_body._user_leave) {
          if (msg_body._channel === get_cur_channel()) {
            $('#msg_list').value += "用户【" + msg_body._user_leave + "】离开\r\n";
          }
      }
      if (msg_body._user_online) {
          if (msg_body._channel === get_cur_channel()) {
            $('#msg_list').value += "用户【" + msg_body._user_online + "】上线\r\n";
          }
      }
      if (msg_body._user_offline) {
          if (msg_body._channel === get_cur_channel()) {
            $('#msg_list').value += "用户【" + msg_body._user_offline + "】离线\r\n";
          }
      }
    },

    onclose: function() {
      nnlog("onclose");
    },
    onerr: function(type, err) {
      switch (type) {
        // case "get_user_info":
        //  // 暂不处理此错误
        //  return;
        default: break;
      }
      nnlog("onerr:" + type + "," + JSON.stringify(err));
    },
  });
}
start();
