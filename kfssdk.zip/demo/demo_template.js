﻿"use strict";
(function(win) {
    var SDK_CONFIG = {
        // TODO:替换为自己在快全栈云开放平台官网注册的app相信息
        appid: 100004,
        appkey: "dekabecyidqrlmbc",
    };
    var CHANNEL_NAME = "demo_template";

    // TODO:根据需要使用var webrtc = kfssdk.webrtc;

    /*
    kfssdk初始化及连接登录服务器
    注：注册的事件只有【onready】事件为强制必须事件(否则系统将报异常)，其它事件仅作为开发模板方便大家学习和直接使用，实际应根据需求选用相关事件，无关事件代码可直接删除
    kfssdk的事件、方法和属性相关参数详见官网相关开发文档
    */
    kfssdk.init({
        // app注册信息
        appid: SDK_CONFIG.appid, // 也可将上面的信息直接写在这里
        appkey: SDK_CONFIG.appkey,

        // no_auto_start: true, // 可通过设置此参数控制仅初始化而不连接和登录服务器，后续合适的时候再调用【kfssdk.start();】进行连接登录服务器

        // 系统事件，生命周期事件
        // *必须注册事件：连接服务器并初始化帐号，登录成功
        onready: function() {
            /*
            每个事件中可加入自己想要的逻辑代码，包括对kfssdk的方法和属性调用，具体事件方法和属性名称和参数详见官网相关开发文档
            kfssdk的大多协议均需要在onready事件发生之后调用方为有效，否则将失败或报错
            后续事件均类似，不再每个重复说明
            TODO:替换和修改为自己的初始化逻辑及参数
            */
            kfssdk.create_channel({
                _channel: CHANNEL_NAME, // 频道名
                _channel_option: { // 频道功能选项参数
                    // _password: "lj", // 允许用户修改
                    // _max_user: 100, // 默认100
                    _max_keep_msg_list_len: 20, // 默认0，处理后立即删除；为-1，则永远不自动删除
                    // _max_keep_msg_time: kfssdk.NO_LIMIT, // 此字段为NO_LIMIT或大于等于server_config.min_store_keep_msg_time值才会存储到硬盘
                    // _join_notify: true,
                    // _leave_notify: true,
                    // _online_notify: true,
                    // _offline_notify: true,
                    // _max_offline_wait_time: kfssdk.NO_LIMIT, // 默认0，立即移除该用户；为-1，则永远不自动删除
                    // _delay_login_millisecond_send: 0, //3000,
                    // _public: false,
                    // _auto_destroy: true,
                    // _allow_publish_users: null, // 默认允许所有频道范围(app或全局)用户发布消息 // 允许用户修改
                    // _ban_publish_users: null, // 默认无禁止发布消息用户 // 允许用户修改
                    // _allow_entry: this.USE_ROBOT_MIN_WAIT_MATCH_MILLISECOND, // 允许用户修改
                    // _allow_modify_all_public_data: true, // 默认undefined，即不允许
                    // _allow_entry_millisecond: kfssdk.NO_LIMIT, -- 允许用户修改
                    // _allow_all_user_invite_user: true, // 默认undefined，即只允许master邀请用户加入
                    // _only_robot_auto_destroy: true, // 默认undefined，即不会自动销毁
                    // _client_request_msg: , // 默认undefined，即由服务器主动推送消息
                    // _only_read_self_public_data: , // 默认undefined，即全部均可读
                    // _client_request_public_data: true, // 默认undefined，即在create_channel或subscribe_channel返回消息中均自动带有_public_data数据，否则需要额外请求get_channel_public_data消息返回；此设置至少适合两种应用场景：1、由master发布内容而其他用户仅能读写自己提交的内容；2、public_data数据很多，采用按需读取模式以优化网络性能；
                    // _user_all_offline_auto_destroy: true, // 默认undefined，即不会自动销毁
                    // _send_self: false, // 默认true，即自身发的公有数据会反向发送回自身
                    // _fixed_master: true, // 默认false，此时master离开将自动设置其他用户为新master并通知channel内其他用户；若设置为true，当原始creator离开后，将会把master设置为null，而creator重新回到channel时将自动设置回其为master并通知
                    // _enable_cluster: {
                    //     // auto_merge: true,
                    // },
                },
                // _begin_service_seq: 0, // 如果频道已存在，则接收从这个消息序号开始的所有消息，默认为empty，表示只接收之后的新消息；此条仅_last_msg_len为空时有效
                _last_msg_len: 20, // 如果频道已经存在，则获取最新消息条数，默认为空，按_begin_service_seq计算
                // _group: this.play_game_with ? this.gen_group_name(this.play_game_with) : undefined,
            });
            kfssdk.show_loading(false);
        },
        // 若未注册此方法，网络断开重连后将再次触发onready事件，具体根据应用需求决定采用哪种触发方案
        // onreconnect: function(msg_body, err_obj, seq) {
        //     console.log("onreconnect:", msg_body, err_obj, seq);
        // },
        // *必须注册事件，若仅使用一个app则此事件可省：切换到不同app
        onswitch_app: function(msg_body, err_obj, seq) {
            console.log("onswitch_app:", msg_body, err_obj, seq);
        },
        // 与服务器断事件
        onclose: function() {
            console.log("onclose");
        },
        // 若需将上面所有消息事件的错误失败消息统一处理，则启用此事件处理函数，否则将通过每个协议处理函数的第二个参数【err_obj】体现出来
        // onerr: function(type, err) {
        //     console.log("onerr:", type, ",", err);
        // },

        // 频道相关事件
        oncreate_channel: function(msg_body, err_obj, seq) {
            // message channel_struct {
            //   optional string _channel = 1;
            //   optional int64 _creator = 2;
            //   optional int64 _create_time = 3;
            //   optional int64 _appid = 4;
            //   optional int64 _master = 5;
            //   optional channel_option_struct _option = 6;
            //   repeated int64 _uid_list = 7;
            //   optional int64 _service_seq = 8;
            //   repeated key_data_struct _public_data = 9;
            //   optional string _group  = 10;
            //   repeated int64 _uid_offline_list = 11; // 对应_uid_list列表的离线时间，如果在线，对应值为0
            // }
            // message create_channel {
            //   optional channel_struct _info  = 1;
            // }
            console.log("oncreate_channel:", msg_body, err_obj, seq);
            if (err_obj) {
                // TODO:失败处理
                return;
            }
            console.assert(msg_body);
            // TODO:成功处理
        },
        ondestroy_channel: function(msg_body, err_obj, seq) {
            console.log("ondestroy_channel:", msg_body, err_obj, seq);
        },
        onpublish_channel_msg: function(msg_body, err_obj, seq) {
            // message publish_channel_msg {
            //     optional int64                  _uid                  = 1;
            //     optional string                 _channel              = 2;
            //     optional string                 _sub_type             = 3;
            //     optional string                 _msg                  = 4; // 可以为普通对象类型，sdk回调应用层前将会把此数据json解析出来
            //     optional int64                  _service_time         = 5; // 服务器收到消息时的服务器时间
            //     optional int64                  _service_seq          = 6; // 服务器收到消息的序号，每个channel独立计算，从0开始
            //     optional int64                  __system_param        = 7; // 系统sdk使用参数，应用层不会使用
            // }
            console.log("onpublish_channel_msg:", msg_body, err_obj, seq);
        },
        onsubscribe_channel: function(msg_body, err_obj, seq) {
            console.log("onsubscribe_channel:", msg_body, err_obj, seq);
        },
        onunsubscribe_channel: function(msg_body, err_obj, seq) {
            console.log("onunsubscribe_channel:", msg_body, err_obj, seq);
        },
        onmodify_channel: function(msg_body, err_obj, seq) {
            // // 主要用于会引发对channel进行修改的相关协议操作后的广播通知，如：modify_channel、add_channel_allow_publish_users、remove_channel_allow_publish_users、add_channel_ban_publish_users、remove_channel_ban_publish_users、set_channel_public_data及unsubscribe_channel(会引发master_change)等，注意：这里我们采用增量更新模式，非全量模式，主要针对_allow_publish_users、_ban_publish_users、_public_data等字段；除了publish_channel_msg其余数据和状态变化均用此协议通知
            // message modify_channel {
            //   optional string _channel      = 1;
            //   optional bool _master_changed   = 2;
            //   optional int64 _master   = 3;
            //   optional bool _password_changed   = 4;
            //   optional string _password   = 5;
            //   optional bool _allow_publish_users_changed   = 6;
            //   repeated int64 _allow_publish_users   = 7; // 通过-uid来表示删除，为空表示删除列表
            //   optional bool _ban_publish_users_changed   = 8;
            //   repeated int64 _ban_publish_users   = 9; // 通过-uid来表示删除，为空表示删除列表
            //   optional bool _allow_entry_changed   = 10;
            //   optional bool _allow_entry   = 11;
            //   optional bool _public_data_changed   = 12;
            //   repeated key_data_struct _public_data      = 13;
            //   optional bool _name_changed   = 14;
            //   optional string _name      = 15;
            //   // 以下4个用户事件区别借用publish_channel_msg方案：此套方案为即时消息模式，不会记入历史消息队列中，离线用户将接收不到此类消息；消息模式方案则反之；理论上应做到两套方案不影响用户使用接口，只影响逻辑意义细节；偏向于后续调整为此套方案
            //   optional int64 _user_join   = 16;
            //   optional int64 _user_leave   = 17;
            //   optional int64 _user_online   = 18;
            //   optional int64 _user_offline   = 19;
            //   optional int64 _service_time   = 20; // 毫秒，主要为兼容publish_channel_msg模式用，后期可考虑替换完旧有代码后删除
            //   optional int64 _uid   = 21; // 命令原始请求者
            //   optional bool _allow_entry_millisecond_changed   = 22;
            //   optional int64 _allow_entry_millisecond   = 23;
            //   optional bool _invite_uid_list_changed   = 24;
            //   repeated int64 _invite_uid_list   = 25;
            //   repeated int64 _failed_invite_uid_list   = 36;
            //   optional bool _remove_uid_list_changed   = 26;
            //   repeated int64 _remove_uid_list   = 27;
            //   optional bool _client_request_msg_changed   = 30;
            //   optional bool _client_request_msg   = 31;
            //   optional bool _remove_msg_service_seq_list_changed   = 32;
            //   repeated int64 _remove_msg_service_seq_list   = 33;
            //   optional bool _user_all_offline_auto_destroy_changed   = 34;
            //   optional bool _user_all_offline_auto_destroy   = 35;
            //   optional bool _use_update_mode = 99;
            // }
            console.log("onchannel_change_channel:", msg_body, err_obj, seq);
            if (msg_body._channel !== CHANNEL_NAME) {
                return;
            }
            if (msg_body._user_join) {
                console.log("用户【" + msg_body._user_join + "】加入\r\n");
            }
            if (msg_body._user_leave) {
                console.log("用户【" + msg_body._user_leave + "】离开\r\n");
            }
            if (msg_body._user_online) {
                console.log("用户【" + msg_body._user_online + "】上线\r\n");
            }
            if (msg_body._user_offline) {
                console.log("用户【" + msg_body._user_offline + "】离线\r\n");
            }
        },

        // 文件相关事件
        onget_file_list: function(msg_body, err_obj, seq) {
            console.log("onget_file_list:", msg_body, err_obj, seq);
        },
        oncreate_dir: function(msg_body, err_obj, seq) {
            console.log("oncreate_dir:", msg_body, err_obj, seq);
        },
        oncreate_file: function(msg_body, err_obj, seq) {
            console.log("oncreate_file:", msg_body, err_obj, seq);
        },
        onread_file: function(msg_body, err_obj, seq) {
            console.log("onread_file:", msg_body, err_obj, seq);
        },
        onwrite_file: function(msg_body, err_obj, seq) {
            console.log("onwrite_file:", msg_body, err_obj, seq);
        },
        onrename_file: function(msg_body, err_obj, seq) {
            console.log("onrename_file:", msg_body, err_obj, seq);
        },
        onrename_dir: function(msg_body, err_obj, seq) {
            console.log("onrename_dir:", msg_body, err_obj, seq);
        },
        onmove_file: function(msg_body, err_obj, seq) {
            console.log("onmove_file:", msg_body, err_obj, seq);
        },
        onmove_dir: function(msg_body, err_obj, seq) {
            console.log("onmove_dir:", msg_body, err_obj, seq);
        },
        ondel_file: function(msg_body, err_obj, seq) {
            console.log("ondel_file:", msg_body, err_obj, seq);
        },
        onunzip_file: function(msg_body, err_obj, seq) {
            console.log("onunzip_file:", msg_body, err_obj, seq);
        },
        onshare_file: function(msg_body, err_obj, seq) {
            console.log("onshare_file:", msg_body, err_obj, seq);
        },
        onget_self_share_file: function(msg_body, err_obj, seq) {
            console.log("onget_self_share_file:", msg_body, err_obj, seq);
        },
        onget_share_file: function(msg_body, err_obj, seq) {
            console.log("onget_share_file:", msg_body, err_obj, seq);
        },
        onsearch_public_share_file: function(msg_body, err_obj, seq) {
            console.log("onsearch_public_share_file:", msg_body, err_obj, seq);
        },
        onmount_share_file: function(msg_body, err_obj, seq) {
            console.log("onmount_share_file:", msg_body, err_obj, seq);
        },
        onunmount_share_file: function(msg_body, err_obj, seq) {
            console.log("onunmount_share_file:", msg_body, err_obj, seq);
        },

        // 其它事件
        // 获取到用户信息
        onuser_info: function(msg_body, err_obj, seq) {
            console.log("onuser_info:", msg_body, err_obj, seq);
            // TODO:
        },
        // 收到他人发送的私人消息
        onsend_private_msg: function(msg_body, err_obj, seq) {
            console.log("onsend_private_msg:", msg_body, err_obj, seq);
        },
        onset_ranking_score: function(msg_body, err_obj, seq) {
            console.log("onset_ranking_score:", msg_body, err_obj, seq);
        },
        onget_ranking: function(msg_body, err_obj, seq) {
            console.log("onget_ranking:", msg_body, err_obj, seq);
        },
        onset_like: function(msg_body, err_obj, seq) {
            console.log("onset_like:", msg_body, err_obj, seq);
        },
        onget_like_num: function(msg_body, err_obj, seq) {
            console.log("onget_like_num:", msg_body, err_obj, seq);
        },
        onget_like_list: function(msg_body, err_obj, seq) {
            console.log("onget_like_list:", msg_body, err_obj, seq);
        },
        onstore_set: function(msg_body, err_obj, seq) {
            console.log("onstore_set:", msg_body, err_obj, seq);
        },
        onstore_update: function(msg_body, err_obj, seq) {
            console.log("onstore_update:", msg_body, err_obj, seq);
        },
        onstore_remove: function(msg_body, err_obj, seq) {
            console.log("onstore_remove:", msg_body, err_obj, seq);
        },
        onstore_get: function(msg_body, err_obj, seq) {
            console.log("onstore_get:", msg_body, err_obj, seq);
        },
        onstore_increase: function(msg_body, err_obj, seq) {
            console.log("onstore_increase:", msg_body, err_obj, seq);
        },
    });

    // TODO:同时支持代码中动态注册和注销相关事件，与kfssdk.init中的on事件类似，但我们主张仅采用其中一种方案
    // kfssdk.addEventListener(event_name, event_funs, event_owner, seq, insert);
    // kfssdk.removeEventListener(event_name, event_funs, event_owner, seq);

    kfssdk.show_loading(true);
})(window);