﻿"use strict";

var $ = $ || function(key) {
    return document.querySelector(key);
}
var logs = [];

function nnlog(s) {
    kfssdk.log_(s);
    if (logs.length >= 50) {
        logs.shift();
    }
    logs.push(s);
    $('#log').value = logs.join("\r\n");
}
// 常量定义
// var CHANNEL_NAME = "demo_map";
var HEAD_PORTRAIT_SIZE = 50; // 单位px
var MAP_EMPTY_VALUE = 0;
var MAP_OBSTACLE_VALUE = 1;
var GRID_SIZE = 10;
var MIN_OBSTACLE_RADIUS = GRID_SIZE / 2;
var MAX_OBSTACLE_RADIUS = GRID_SIZE;
var MAP_W = GRID_SIZE * 15;
var MAP_H = GRID_SIZE * 15;
var VISIBLE_W = GRID_SIZE * 10;
var VISIBLE_H = GRID_SIZE * 10;
var SPEED = 0.02;
var DELAY_REQUEST_MOVE = 50; //减少服务器请求次数
var NET_DELAY = 40; //延迟处理以便尽可能同步每个客户端及不产生突兀效果
// 变量定义
var map = [];
var pix_per_unit = 1; // 每单位px，根据屏幕计算得出
var visible_left_pixel = 0;
var visible_top_pixel = 0;
var move_dst = {
    clientX: 0,
    clientY: 0
};
var id_request_move = null;
var canvas = null; //$("#map");
var ctx = null; //canvas.getContext("2d");
// var tmp_canvas = null;
var tmp_ctx = null;
var is_need_update = null;
var users = {
    // uid:{
    //   size:1,
    //   uid: kfssdk.uid,
    //   nickname: kfssdk.nickname,
    //   _head_portrait: kfssdk.head_portrait,
    //   head_portrait:new Image(), head_portrait.src="flower.png"
    //   src_pos:{
    //     x:0,
    //     y:0,
    //   },
    //   pos:{
    //     x:0,
    //     y:0,
    //   },
    //   last_move:{
    //     service_time:0,
    //     dst_pos:{
    //       x:0,
    //       y:0,
    //     }
    //   }
    // }
};
var uid_master = null;
var id_interval = null;

function random_int(max, min) {
    return (min || 0) + Math.floor(Math.random() * max);
}

function calc_diff(x1, y1, x2, y2) {
    return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
}

function calc_diff_by_pos(pos1, pos2) {
    return calc_diff(pos1.x, pos1.y, pos2.x, pos2.y);
}

function is_equal(f1, f2) {
    var EPSILON = 0.1;
    return (Math.abs(f1 - f2) < EPSILON);
}

function random_gen_map() {
    kfssdk.log_("random_gen_map");
    // 生成空地图
    for (var r = 0; r < MAP_H; r++) {
        map[r] = [];
        for (var c = 0; c < MAP_W; c++) {
            map[r][c] = MAP_EMPTY_VALUE;
        }
    }
    // 生成障碍物
    for (var i = 0; i < 4; i++) {
        var r = random_int(MAP_H);
        var c = random_int(MAP_W);
        var s = random_int(MAX_OBSTACLE_RADIUS, MIN_OBSTACLE_RADIUS);
        for (var row = Math.max(0, r - s); row < Math.min(MAP_H, r + s); row++) {
            for (var col = Math.max(0, c - s); col < Math.min(MAP_W, c + s); col++) {
                if (calc_diff(col, row, c, r) <= s) {
                    map[row][col] = MAP_OBSTACLE_VALUE;
                }
            }
        }
    }
}

function i_is_master() {
    return (uid_master == kfssdk.uid);
}

function get_self() {
    return users[kfssdk.uid];
}

function to_client_time(service_time) {
    return service_time + NET_DELAY;
}

function cur_client_time() {
    return to_client_time(kfssdk.cur_service_time());
}

function onset_head_portrait() {
    if (is_start_game()) {
        onchange_self_info();
        return;
    }
    kfssdk.show_loading(true);
    nnlog("kfssdk.create_channel [" + CHANNEL_NAME + "]");
    kfssdk.create_channel({
        _channel: CHANNEL_NAME,
        _channel_option: {
            //   _password: CHANNEL_NAME, // 订阅密码
            //   _max_user: 100, // 默认100
            //   _max_keep_msg_list_len: 0, // 默认0，处理后立即删除
            //   _max_keep_msg_time: 0, // 默认0，处理后立即删除
            //   _join_notify: true, // 默认true，每个新加入/订阅的用户均会双向通知到所有人及将所有人通知给新人
            //   _leave_notify: true, // 默认true，每个离开/取消订阅的用户均会双向通知到所有人及将所有人通知给新人
            //   _max_offline_wait_time: 0, // 默认0，立即移除该用户
            //   _public: false, // 默认false，仅当前app内可见，作用域为当前app范围；否为为全系统范围
            //   _auto_destroy: true, // 默认true，当频道无人时自动销毁
            //   _allow_publish_users: null, // 默认nil，即允许所有频道范围(app或全局)
        },
        // _begin_service_seq: Number(kfssdk.getItem(CHANNEL_NAME + "_seq")) || 0, // 如果频道已存在，则接收从这个消息序号开始的所有消息，默认为nil，表示只接收之后的新消息；此条仅_last_msg_len为空时有效
        // _last_msg_len: 20, // 如果频道已经存在，则获取最新消息条数，默认为空，按_begin_service_seq计算
    });
}

function update_pos(user, service_time) {
    if (user.src_pos == user.last_move.dst_pos) {
        return;
    }
    var s_move = SPEED * ((service_time || kfssdk.cur_service_time()) -
        user.last_move.service_time);
    if (s_move <= 0) { //防止延时机制造成倒退的效果
        // kfssdk.alert_("(s_move <= 0)");
        return true;
    }
    var s_diff = calc_diff_by_pos(user.src_pos, user.last_move.dst_pos);
    if ((s_move >= s_diff)) {
        user.src_pos = user.last_move.dst_pos;
        user.pos = user.src_pos;
        return true;
    }
    //注意：以下如果不加Math.ceil则移动会更圆滑，但障碍物动会有抖动；加了则正好相反
    user.pos.x = user.src_pos.x + Math.ceil((user.last_move.dst_pos.x - user.src_pos.x) * s_move / s_diff);
    user.pos.y = user.src_pos.y + Math.ceil((user.last_move.dst_pos.y - user.src_pos.y) * s_move / s_diff);
    if (isNaN(user.pos.x) || isNaN(user.pos.y)) {
        kfssdk.assert_(0);
    }
    return true;
}
// 可视区逻辑坐标到画布鼠标坐标
function visible_to_canvas_x_pixel(x) {
    return visible_left_pixel + pix_per_unit * x;
}

function visible_to_canvas_y_pixel(y) {
    return visible_top_pixel + pix_per_unit * y;
}
// 可视区逻辑坐标到地图逻辑坐标
function visible_to_map_x(x) {
    var self = get_self();
    var x2 = self.pos.x + (x - VISIBLE_W / 2);
    return Math.min(MAP_W - 1, Math.max(0, Math.floor(x2)));
}

function visible_to_map_y(y) {
    var self = get_self();
    var y2 = self.pos.y + (y - VISIBLE_W / 2);
    return Math.min(MAP_H - 1, Math.max(0, Math.floor(y2)));
}
// 画布鼠标坐标到可视区逻辑坐标
function canvas_to_visible_x(x) {
    return Math.min(VISIBLE_W - 1, Math.max(0, Math.floor((x - visible_left_pixel) / pix_per_unit)));
}

function canvas_to_visible_y(y) {
    return Math.min(VISIBLE_H - 1, Math.max(0, Math.floor((y - visible_top_pixel) / pix_per_unit)));
}
// 画布鼠标坐标到地图逻辑坐标
function canvas_to_map_x(x) {
    var x1 = canvas_to_visible_x(x);
    return visible_to_map_x(x1);
}

function canvas_to_map_y(y) {
    var y1 = canvas_to_visible_y(y);
    return visible_to_map_y(y1);
}

function drawCircleImg(ctx, img, x, y, r) {
    ctx.save();
    var d = 2 * r;
    var cx = x + r;
    var cy = y + r;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, 2 * Math.PI);
    ctx.clip();
    ctx.closePath();
    ctx.drawImage(img, x, y, d, d);
    ctx.restore();
}

function draw_map() {
    if (!is_start_game()) {
        return;
    }
    // 玩家自身永远在窗口中心点
    var self = get_self();
    tmp_ctx.fillStyle = "#000000";
    tmp_ctx.fillRect(0, 0, canvas.width, canvas.height);
    var left = visible_to_canvas_x_pixel(Math.max(0, VISIBLE_W / 2 - self.pos.x));
    var top = visible_to_canvas_y_pixel(Math.max(0, VISIBLE_H / 2 - self.pos.y));
    var right = visible_to_canvas_x_pixel(Math.min(VISIBLE_W, VISIBLE_W / 2 + MAP_W - self.pos.x));
    var bottom = visible_to_canvas_y_pixel(Math.min(VISIBLE_H, VISIBLE_H / 2 + MAP_H - self.pos.y));
    // 画地图背景
    tmp_ctx.beginPath();
    tmp_ctx.fillStyle = "#00ff00";
    tmp_ctx.fillRect(left, top, right - left, bottom - top);
    //网格
    tmp_ctx.strokeStyle = "#0000ff";
    tmp_ctx.lineWidth = 1;
    //水平线
    var y = (VISIBLE_H / 2 - self.pos.y) % GRID_SIZE;
    for (;; y += GRID_SIZE) {
        var y1 = visible_to_canvas_y_pixel(y);
        if (y1 < top) {
            continue;
        }
        if (y1 >= bottom) {
            break;
        }
        tmp_ctx.moveTo(left, y1);
        tmp_ctx.lineTo(right, y1);
        tmp_ctx.stroke();
    }
    //垂直线
    var x = (VISIBLE_W / 2 - self.pos.x) % GRID_SIZE;
    for (;; x += GRID_SIZE) {
        if (visible_to_canvas_x_pixel(x) < left) {
            continue;
        }
        if (visible_to_canvas_x_pixel(x) >= right) {
            break;
        }
        tmp_ctx.moveTo(visible_to_canvas_x_pixel(x), (top));
        tmp_ctx.lineTo(visible_to_canvas_x_pixel(x), (bottom));
        tmp_ctx.stroke();
    }

    // 画障碍物
    tmp_ctx.fillStyle = "#ff0000";
    for (var row = 0; row < VISIBLE_H; row++) {
        for (var col = 0; col < VISIBLE_W; col++) {
            var r = visible_to_map_y(row);
            var c = visible_to_map_x(col);
            if (map[r][c] == MAP_OBSTACLE_VALUE) {
                var x = visible_to_canvas_x_pixel(col);
                var y = visible_to_canvas_y_pixel(row);
                x = Math.max(left, x);
                x = Math.min(right, x);
                y = Math.max(top, y);
                y = Math.min(bottom, y);
                tmp_ctx.fillRect(x, y, pix_per_unit, pix_per_unit);
            }
        }
    }

    // 画用户列表
    tmp_ctx.fillStyle = "#ff00ff";
    tmp_ctx.font = "30px Arial";
    for (var uid in users) {
        var user = users[uid];
        if (!user.head_portrait.complete) {
            continue;
        }
        var x1 = visible_to_canvas_x_pixel(VISIBLE_W / 2 + user.pos.x - self.pos.x - HEAD_PORTRAIT_SIZE / pix_per_unit / 2);
        var y1 = visible_to_canvas_y_pixel(VISIBLE_H / 2 + user.pos.y - self.pos.y - HEAD_PORTRAIT_SIZE / pix_per_unit / 2);
        drawCircleImg(tmp_ctx, user.head_portrait, x1, y1, HEAD_PORTRAIT_SIZE / 2);
        tmp_ctx.fillText(user.nickname, x1 - 2, y1 - 5);
    }

    tmp_ctx.fillStyle = "#000000";
    tmp_ctx.fillRect(0, 0, canvas.width, top);
    tmp_ctx.fillRect(0, bottom, canvas.width, canvas.height - bottom);
    tmp_ctx.fillRect(0, 0, left, canvas.height);
    tmp_ctx.fillRect(right, 0, canvas.width - right, canvas.height);

    tmp_ctx.fillStyle = "#ff00ff";
    tmp_ctx.font = "14px Arial";
    tmp_ctx.fillText(("x:" + Math.floor(self.pos.x) + "  y:" + Math.floor(self.pos.y)),
        visible_to_canvas_x_pixel(VISIBLE_W / 2) - HEAD_PORTRAIT_SIZE / 2 - 5,
        visible_to_canvas_y_pixel(VISIBLE_H / 2) + HEAD_PORTRAIT_SIZE / 2 + 10);

    //ctx.drawImage(tmp_canvas,0,0);
}

function run_loop() {
    if (!is_need_update) {
        return;
    }
    is_need_update = false;
    var service_time = kfssdk.cur_service_time();
    for (var uid in users) {
        var user = users[uid];
        is_need_update = update_pos(user, service_time) || is_need_update;
    }
    if (is_need_update) {
        draw_map();
    }
}

function is_start_game() {
    return id_interval;
}

function start_game() {
    kfssdk.log_("start_game");
    kfssdk.assert_(!is_start_game());
    is_need_update = true;
    stop_game();
    id_interval = setInterval(run_loop, 1000 / 25);
    draw_map(); //强制绘制，解决首次因src_pos与dst_pos相同不会触发绘制的问题
    kfssdk.show_loading(false);
}

function stop_game() {
    if (id_interval) {
        clearInterval(id_interval);
    }
    id_interval = null;
}

function update_user_info(user) {
    if (!(user.head_portrait instanceof Image)) {
        user.head_portrait = new Image();
    }
    user.head_portrait.src = user.head_portrait_url;
    users[user.uid] = user;
    return user;
}

function init_self() {
    //自己初始化自身信息
    var pos = {
        x: random_int(MAP_W),
        y: random_int(MAP_H),
    };
    var user = {
        size: 1,
        uid: kfssdk.uid,
        nickname: kfssdk.nickname,
        head_portrait_url: kfssdk.get_head_portrait(kfssdk),
        src_pos: pos,
        pos: pos,
        last_move: {
            service_time: kfssdk.cur_service_time(),
            dst_pos: pos
        }
    };
    update_user_info(user);
}

function encode_public_data(data) {
    // return JSON.stringify(data)
    return data;
}

function decode_public_data(data) {
    // return JSON.parse(data)
    return data;
}

function send_self_info() {
    var self = get_self();
    kfssdk.modify_channel({
        _channel: CHANNEL_NAME,
        _public_data_changed: true,
        _public_data: [{
            _key: self.uid,
            _data: encode_public_data(self)
        }],
        _use_update_mode: true
    });
}

function onchange_self_info() {
    var self = get_self();
    if (!self || !is_start_game()) {
        return;
    }
    self.nickname = kfssdk.nickname;
    self.head_portrait_url = kfssdk.get_head_portrait(kfssdk);
    update_user_info(self)
    send_self_info();
    draw_map();
}

function onpublic_data_update(msg_body) {
    // :<function({_channel:<channel>, _public_data:<key_data>})>,;
    var has_map_data = false;
    for (var i = 0; i < msg_body._public_data.length; i++) {
        var _public_data = msg_body._public_data[i];
        var key = _public_data._key;
        var data = _public_data._data;
        data = decode_public_data(data);
        if ("map" == key) {
            map = data;
            has_map_data = true;
            continue;
        }
        //将前次移动结束
        var user = users[key];
        if (is_start_game() && user) {
            update_pos(user, _public_data._service_time);
            //按新的目标、时间、起点开始新的移动
            data.src_pos = user.pos;
        }
        data.last_move.service_time = _public_data._service_time;
        update_user_info(data);
    }
    if (has_map_data) {
        start_game();
    } else {
        is_need_update = true;
    }
}

function oncreate_or_onsubscribe_channel(msg_body) {
    // msg_body: {
    //     _info: {
    //         _channel:CHANNEL_NAME, 
    //         _creator:?, 
    //         _create_time:?, 
    //         _appid:?, 
    //         _master:100003, 
    //         _option:?,
    //         _uid_list:[100003,100013], 
    //         _service_seq:?,
    //         _public_data:[?]
    //     }
    // }
    msg_body = msg_body._info;
    users = [];
    for (var i = msg_body._uid_list.length - 1; i >= 0; i--) {
        users[msg_body._uid_list[i]] = {};
    }
    uid_master = msg_body._master;
    //注意顺序，避免被_uid_list覆盖
    init_self();
    var self = get_self();
    var _public_data = [];
    if (i_is_master()) {
        // master同时负责主持服务器逻辑
        random_gen_map();
        _public_data.push({
            _key: "map",
            _data: encode_public_data(map)
        });
    }
    _public_data.push({
        _key: self.uid,
        _data: encode_public_data(self)
    });
    nnlog("kfssdk.modify_channel [" + CHANNEL_NAME + "]");
    kfssdk.modify_channel({
        _channel: CHANNEL_NAME,
        _public_data_changed: true,
        _public_data: _public_data,
        _use_update_mode: true
    });
    if (!i_is_master()) {
        onpublic_data_update(msg_body);
    }
}

function request_move() {
    id_request_move = null;
    var x = canvas_to_map_x(move_dst.clientX);
    var y = canvas_to_map_y(move_dst.clientY);
    // TODO:计算障碍物
    // 另一套方案：kfssdk.publish_channel_msg(CHANNEL_NAME, "move_to", {x: x, y: y});
    var self = get_self();
    var tmp = self.last_move.dst_pos;
    self.last_move.dst_pos = {
        x: x,
        y: y
    };
    send_self_info();
    self.last_move.dst_pos = tmp;
}
// window.onload = function() {
function start() {
    canvas = $("#map");
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    ctx = canvas.getContext("2d");

    // 双缓存机制并没有效果
    // tmp_canvas = document.createElement('canvas');
    // tmp_canvas.width = canvas.width;
    // tmp_canvas.height = canvas.height;
    tmp_ctx = ctx; //tmp_canvas.getContext("2d");

    visible_left_pixel = Math.max(0, (window.innerWidth - window.innerHeight) / 2);
    visible_top_pixel = Math.max(0, (window.innerHeight - window.innerWidth) / 2);
    pix_per_unit = Math.min(window.innerWidth, window.innerHeight) / VISIBLE_W;
    canvas.onmousemove = function(e) {
        nnlog(e);
        if (!is_start_game()) {
            return;
        }
        move_dst.clientX = e.clientX;
        move_dst.clientY = e.clientY;
        if (!id_request_move) {
            id_request_move = setTimeout(request_move, DELAY_REQUEST_MOVE);
        }
    }

    nnlog("kfssdk.init");

    function init() {
        nnlog("onready || onreconnect");
        // if (NET_DELAY * 2 < kfssdk._net_time) {
        //   kfssdk.alert_("(NET_DELAY * 2 < kfssdk._net_time):" + kfssdk._net_time);
        // }
        if (kfssdk.head_portrait) {
            onset_head_portrait();
        } else {
            kfssdk.head_portrait_set();
        }
    }
    kfssdk.init({
        appid: SDK_CONFIG.appid,
        appkey: SDK_CONFIG.appkey,
        sync_time: true,
        onready: init,

        onuser_info: function(_user_base_info) {
            nnlog("onuser_info:" + JSON.stringify(_user_base_info));
            if (kfssdk.is_self(_user_base_info._uid)) {
                onchange_self_info();
            }
        },
        onset_head_portrait: onset_head_portrait,
        onsend_private_msg: function(msg_body) {
            nnlog("onsend_private_msg:" + JSON.stringify(msg_body));
            // var data = msg_body._msg;
            // switch(msg_body._sub_type){
            //   case "init_info":
            //     map = data.map;
            //     for(var i in data.users){
            //       var user = data.users[i];
            //       update_user_info(user);
            //     }
            //     start_game();
            //     break;
            // }
        },
        oncreate_channel: function(msg_body) {
            nnlog("oncreate_channel:" + JSON.stringify(msg_body));
            oncreate_or_onsubscribe_channel(msg_body);
        },
        ondestroy_channel: function(msg_body) {
            nnlog("ondestroy_channel:" + JSON.stringify(msg_body));
        },
        onpublish_channel_msg: function(msg_body) {
            var data = JSON.stringify(msg_body);
            nnlog("onpublish_channel_msg:" + data);
            var user = users[msg_body._uid];
            switch (msg_body._sub_type) {
                // case "move_to":
                //   update_pos(user, msg_body._service_time);
                //   user.last_move.dst_pos = msg_body._msg;
                //   user.last_move.service_time = msg_body._service_time;
                //   is_need_update = true;
                //   break;
                default:
                    kfssdk.alert_("unknow sub_type:" + data);
            }
        },
        onsubscribe_channel: function(msg_body) {
            nnlog("onsubscribe_channel:" + JSON.stringify(msg_body));
            oncreate_or_onsubscribe_channel(msg_body);
        },
        onunsubscribe_channel: function(msg_body) {
            nnlog("onunsubscribe_channel:" + JSON.stringify(msg_body));
        },
        onmodify_channel: function(msg_body) {
            nnlog("onmodify_channel:" + JSON.stringify(msg_body));
            // if (msg_body._user_join) {
            //     msg_body._uid = msg_body._user_join;
            //     kfssdk._app.onuser_join(msg_body);
            // }
            // if (msg_body._user_leave) {
            //     msg_body._uid = msg_body._user_leave;
            //     kfssdk._app.onuser_leave(msg_body);
            // }
            // if (msg_body._user_online) {
            //     msg_body._uid = msg_body._user_online;
            //     kfssdk._app.onuser_online(msg_body);
            // }
            // if (msg_body._user_offline) {
            //     msg_body._uid = msg_body._user_offline;
            //     kfssdk._app.onuser_offline(msg_body);
            // }
            if (msg_body._master_changed) {
                uid_master = msg_body._master;
            }
            if (msg_body._public_data_changed) {
                onpublic_data_update(msg_body);
            }
        },
        onuser_join: function(msg_body) {
            var data = JSON.stringify(msg_body);
            nnlog("onuser_join:" + data);
        },
        onuser_leave: function(msg_body) {
            var data = JSON.stringify(msg_body);
            nnlog("onuser_leave:" + data);
            //users[msg_body._uid] = null; //undefined; //经测试此两种模式都会遗留该字段值
            delete users[msg_body._uid];
            is_need_update = true;
            draw_map(); // 强制重画
        },
        onuser_online: function(msg_body) {
            var data = JSON.stringify(msg_body);
            nnlog("onuser_online:" + data);
        },
        onuser_offline: function(msg_body) {
            var data = JSON.stringify(msg_body);
            nnlog("onuser_offline:" + data);
        },

        onclose: function() {
            nnlog("onclose");
            stop_game();
        },
        onerr: function(type, err) {
            switch (type) {
                // case "get_user_info":
                //  // 暂不处理此错误
                //  return;
                default:
                    break;
            }
            nnlog("onerr:" + type + "," + JSON.stringify(err));
        },
    });
}
start();