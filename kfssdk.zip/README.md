# zsq 快全栈云开放平台
平台官网：
https://fastfullstack.com/
快全栈云开放平台本质上属于云计算领域的paas平台，为saas软件提供服务。不同于同类云服务平台的主要点是本平台更偏业务层，通俗的讲即更接地气，更好用、实用。
其目的主要是通过将服务器通用功能及数据结构提取抽象为api接口作为通用服务供各类客服端调用，从而大大减少甚至完全规避服务端的开发工作及维护、测试工作。

# 平台案例展示
https://fastfullstack.com/#case


# 平台开发文档
https://fastfullstack.com/#doc


# 其它问题
https://fastfullstack.com/#faq

# 联系
点击下方链接加入官方QQ群(251860015)交流：

https://jq.qq.com/?_wv=1027&k=5xrcTGg

加官方客服微信咨询(链接为微信二维码)：liujun_is_me

https://fastfullstack.com/img/common/liujun_is_me.jpg